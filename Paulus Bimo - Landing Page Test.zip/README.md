<img src="./src/assets/DroNeeds_White.svg" width="300">

<br>

## Link: ***https://droneeds.netlify.app/***

DroNeeds is the largest drone publisher company and drone service providers in Indonesia. We help our customers to fullfilled their satisfaction.

## **Tech Stack**
- React JS sebagai library
- Tailwind untuk styling dan layouting
- EmailJS untuk mengirim API pada section ***Contact Us***

## **Preview**

#### Home Page
<img src="./src/assets/DroNeeds_Home.png" width="100%">

#### Products Page
<img src="./src/assets/DroNeeds_Products.png" width="100%">