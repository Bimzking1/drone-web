import React from 'react'
import { Outlet } from 'react-router'

const Main = () => {
  return (
    <div className=''>
        <Outlet/>
    </div>
  )
}

export default Main